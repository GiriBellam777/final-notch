import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Products } from './products';
import { Cart } from './cart';
import { CartTotal } from './cartTotal';
import { User } from './user';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  prod:Observable<Products>;

  constructor(private httpClient:HttpClient) { }

 public showProducts():Observable<Products>
 {
   return this.httpClient.get<Products>("http://localhost:9200/viewProducts");
 }
 
 public addProductsToCart(cart)
 {
  console.log(cart);  
  return this.httpClient.post<Cart>("http://localhost:9200/add/" ,cart)
 
 }

 public showProductsInCart():Observable<Products>
 {
   return this.httpClient.get<Products>("http://localhost:9200/viewCart");
 }
 
 public removeProductFromCart(id):Observable<Products>
 {
   return this.httpClient.delete<Products>("http://localhost:9200/remove/"+id);
 }

 public checkCartValue():Observable<number>
 {
   return this.httpClient.get<number>("http://localhost:9200/checkCart");
 }

public placeOrder(user:User){
  console.log(user);
  let url='http://localhost:9200/placeOrder';
  //console.log(user.accNo+" "+user.pin);
  return this.httpClient.post<User>(url,user);
 
}

}
