package com.cg.capStore.bean;



import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

public class CapStore {
	
	@Id
	private Date capDate;
	
	private double revenue;
	
	

	public CapStore() {
		super();
		
	}

	public CapStore(Date capDate, double revenue) {
		super();
		this.capDate = capDate;
		this.revenue = revenue;
	}

	public Date getCapDate() {
		return capDate;
	}

	public void setCapDate(Date capDate) {
		this.capDate = capDate;
	}

	public double getRevenue() {
		return revenue;
	}

	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	
	
	

}
