package com.cg.capStore.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CapUser {
	
	@Id
	private String accountNo;
	private String pin;
	private double accountBalance;
	
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
}
