package com.cg.capStore.service;


import java.util.List;

import com.cg.capStore.bean.Cart;
import com.cg.capStore.bean.Products;
import com.cg.capStore.bean.CapUser;
import com.cg.capStore.exception.CartException;


public interface CartService 
{	
	 public List<Products> viewProducts();
	 
    public List<Cart> viewcartProducts();
	
	public void addToCart(Cart cart);
	
	public List<Cart> deleteFromCart(int id);
	
	public double checkCartTotal();
	
	public void placeOrder(CapUser user);
	
	public void updateRevenue(double amount);
}
